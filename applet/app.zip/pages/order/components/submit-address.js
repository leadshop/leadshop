(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-address"],{"5c00":function(n,t,e){"use strict";var a;e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return i})),e.d(t,"a",(function(){return a}));var u=function(){var n=this,t=n.$createElement;n._self._c},i=[]},"78b5":function(n,t,e){"use strict";e.r(t);var a=e("fab5"),u=e.n(a);for(var i in a)["default"].indexOf(i)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(i);t["default"]=u.a},d78f:function(n,t,e){"use strict";e.r(t);var a=e("5c00"),u=e("78b5");for(var i in u)["default"].indexOf(i)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(i);e("da5b");var r,f=e("f0c5"),o=Object(f["a"])(u["default"],a["b"],a["c"],!1,null,"6a17f641",null,!1,a["a"],r);t["default"]=o.exports},da5b:function(n,t,e){"use strict";var a=e("df6d"),u=e.n(a);u.a},df6d:function(n,t,e){},fab5:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"submit-address",props:{consigneeInfo:{type:Object}},methods:{navigateTo:function(){var t="/pages/user/shipping-address?submit=1";this.consigneeInfo&&(t+="&id="+this.consigneeInfo.id),n.navigateTo({url:t})}}};t.default=e}).call(this,e("543d")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-address-create-component',
    {
        'pages/order/components/submit-address-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("d78f"))
        })
    },
    [['pages/order/components/submit-address-create-component']]
]);
