module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.1.5",
    "AppURL": "",
    "siteroot": "",
    "design_method": "3"
}