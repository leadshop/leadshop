module.exports  = {
    "uniacid": "3",
    "acid": "3",
    "multiid": "0",
    "version": "2",
    "AppURL": "https://open.heshop.vip",
    "siteroot":"",
    "design_method": "3"
}
