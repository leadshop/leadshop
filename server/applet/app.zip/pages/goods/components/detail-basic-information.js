(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-basic-information"],{"100c":function(e,t,n){"use strict";var u=n("b402"),r=n.n(u);r.a},abf8:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=function(){n.e("components/he-share").then(function(){return resolve(n("3f1e"))}.bind(null,n)).catch(n.oe)},r={name:"detail-basic-information",components:{heShare:u},props:{name:{type:String,default:""},price:{type:String,default:""},unit:{type:String,default:""},linePrice:{type:String,default:""},sales:{type:Number,default:0},virtual_sales:{type:Number,default:0},goodsId:{type:Number,default:function(){return 0}},goods:{type:Object}},data:function(){return{show:!1,list:[]}},methods:{}};t.default=r},b402:function(e,t,n){},bde5:function(e,t,n){"use strict";n.r(t);var u=n("abf8"),r=n.n(u);for(var a in u)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(a);t["default"]=r.a},de64:function(e,t,n){"use strict";var u;n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return a})),n.d(t,"a",(function(){return u}));var r=function(){var e=this,t=e.$createElement;e._self._c;e._isMounted||(e.e0=function(t){e.show=!0})},a=[]},ff37:function(e,t,n){"use strict";n.r(t);var u=n("de64"),r=n("bde5");for(var a in r)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(a);n("100c");var o,i=n("f0c5"),f=Object(i["a"])(r["default"],u["b"],u["c"],!1,null,"cf1111d0",null,!1,u["a"],o);t["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-basic-information-create-component',
    {
        'pages/goods/components/detail-basic-information-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("ff37"))
        })
    },
    [['pages/goods/components/detail-basic-information-create-component']]
]);
