(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"088c":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c=function(){Promise.all([t.e("common/vendor"),t.e("components/he-html/he-html")]).then(function(){return resolve(t("7dc4"))}.bind(null,t)).catch(t.oe)},a={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:c}};e.default=a},"18b3":function(n,e,t){"use strict";t.r(e);var c=t("45ae"),a=t("9aa4");for(var r in a)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(r);t("be68");var o,u=t("f0c5"),i=Object(u["a"])(a["default"],c["b"],c["c"],!1,null,"30b91ab3",null,!1,c["a"],o);e["default"]=i.exports},"45ae":function(n,e,t){"use strict";var c;t.d(e,"b",(function(){return a})),t.d(e,"c",(function(){return r})),t.d(e,"a",(function(){return c}));var a=function(){var n=this,e=n.$createElement;n._self._c},r=[]},"9aa4":function(n,e,t){"use strict";t.r(e);var c=t("088c"),a=t.n(c);for(var r in c)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return c[n]}))}(r);e["default"]=a.a},be68:function(n,e,t){"use strict";var c=t("fc6a"),a=t.n(c);a.a},fc6a:function(n,e,t){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
