(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-logistics"],{"07e8":function(t,n,e){"use strict";e.r(n);var c=e("0871"),u=e("b6cf");for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e("bcc4");var i,a=e("f0c5"),o=Object(a["a"])(u["default"],c["b"],c["c"],!1,null,"fbb5a496",null,!1,c["a"],i);n["default"]=o.exports},"0871":function(t,n,e){"use strict";var c;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return c}));var u=function(){var t=this,n=t.$createElement;t._self._c},r=[]},"99a6":function(t,n,e){},b6cf:function(t,n,e){"use strict";e.r(n);var c=e("d808"),u=e.n(c);for(var r in c)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(r);n["default"]=u.a},bcc4:function(t,n,e){"use strict";var c=e("99a6"),u=e.n(c);u.a},d808:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c={name:"detail-logistics",props:{freight:{type:Object,default:function(){return{}}}},methods:{copy:function(t){this.uniCopy({content:t})}}};n.default=c}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-logistics-create-component',
    {
        'pages/order/components/detail-logistics-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("07e8"))
        })
    },
    [['pages/order/components/detail-logistics-create-component']]
]);
