(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-price"],{"3d8b":function(t,n,e){},7963:function(t,n,e){"use strict";e.r(n);var r=e("a7c8"),u=e("f6b5");for(var c in u)["default"].indexOf(c)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(c);e("7ec0");var a,f=e("f0c5"),i=Object(f["a"])(u["default"],r["b"],r["c"],!1,null,"3cb32789",null,!1,r["a"],a);n["default"]=i.exports},"7ec0":function(t,n,e){"use strict";var r=e("3d8b"),u=e.n(r);u.a},"8c77":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"detail-price",props:{goodsAmount:{type:String,default:function(){return""}},freightAmount:{type:String,default:function(){return""}},payAmount:{type:String,default:function(){return""}}}};n.default=r},a7c8:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return c})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},c=[]},f6b5:function(t,n,e){"use strict";e.r(n);var r=e("8c77"),u=e.n(r);for(var c in r)["default"].indexOf(c)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(c);n["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-price-create-component',
    {
        'pages/order/components/detail-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7963"))
        })
    },
    [['pages/order/components/detail-price-create-component']]
]);
