<?php
/**
 * Creates a call for the method `yii\db\Migration::createTable()`
 */
/* @var $table string the name table */
/* @var $tableComment string the comment table */
?>        $this->addCommentOnTable('<?= $table ?>', '<?= $tableComment ?>');
