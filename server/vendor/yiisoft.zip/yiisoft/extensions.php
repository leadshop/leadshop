<?php

$vendorDir = dirname(__DIR__);

return array (
  'linslin/yii2-curl' => 
  array (
    'name' => 'linslin/yii2-curl',
    'version' => '1.5.0.0',
    'alias' => 
    array (
      '@linslin/yii2/curl' => $vendorDir . '/linslin/yii2-curl',
    ),
  ),
  'shmilyzxt/yii2-queue' => 
  array (
    'name' => 'shmilyzxt/yii2-queue',
    'version' => 'dev-dev',
    'alias' => 
    array (
      '@shmilyzxt/queue' => $vendorDir . '/shmilyzxt/yii2-queue',
    ),
  ),
  'sizeg/yii2-jwt' => 
  array (
    'name' => 'sizeg/yii2-jwt',
    'version' => '2.0.1.1',
    'alias' => 
    array (
      '@sizeg/jwt' => $vendorDir . '/sizeg/yii2-jwt',
    ),
  ),
  'yiisoft/yii2-bootstrap' => 
  array (
    'name' => 'yiisoft/yii2-bootstrap',
    'version' => '2.0.10.0',
    'alias' => 
    array (
      '@yii/bootstrap' => $vendorDir . '/yiisoft/yii2-bootstrap/src',
    ),
  ),
  'yiisoft/yii2-imagine' => 
  array (
    'name' => 'yiisoft/yii2-imagine',
    'version' => '2.3.0.0',
    'alias' => 
    array (
      '@yii/imagine' => $vendorDir . '/yiisoft/yii2-imagine/src',
    ),
  ),
  'yiisoft/yii2-swiftmailer' => 
  array (
    'name' => 'yiisoft/yii2-swiftmailer',
    'version' => '2.1.2.0',
    'alias' => 
    array (
      '@yii/swiftmailer' => $vendorDir . '/yiisoft/yii2-swiftmailer/src',
    ),
  ),
  'yiisoft/yii2-debug' => 
  array (
    'name' => 'yiisoft/yii2-debug',
    'version' => '2.1.16.0',
    'alias' => 
    array (
      '@yii/debug' => $vendorDir . '/yiisoft/yii2-debug/src',
    ),
  ),
  'yiisoft/yii2-faker' => 
  array (
    'name' => 'yiisoft/yii2-faker',
    'version' => '2.0.5.0',
    'alias' => 
    array (
      '@yii/faker' => $vendorDir . '/yiisoft/yii2-faker/src',
    ),
  ),
  'yiisoft/yii2-gii' => 
  array (
    'name' => 'yiisoft/yii2-gii',
    'version' => '2.1.4.0',
    'alias' => 
    array (
      '@yii/gii' => $vendorDir . '/yiisoft/yii2-gii/src',
    ),
  ),
);
